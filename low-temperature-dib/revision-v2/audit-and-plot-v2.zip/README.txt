本包包含V2修订对比表、Origin数据、严格/条件图和新增证据。
旧版基础原始资料另见GitHub low-temperature-dib/dib-verification-evidence.zip。
严格图和条件图的文献比值分开：条件图空心点的比值1是对称协议假设，不能当作分别报告的两向倍率。
