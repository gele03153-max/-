# 两篇待定候选的核验结果

本次未增加主表文献或可作图点。以下“NV”表示尚未核实，不能写成原文未报告（NR）。

## 10.1002/adfm.202600020

出版社向 Crossref 提交的摘要明确：P(PZ2TPA-TPP) 在 **−20 °C 下100天、100%容量保持率**。这是时间指标；摘要没有对应循环圈数，没有独立充、放电倍率，也没有明确该低温测试的负极。不能由100天推算循环数。

摘要另述实用 P(PZ2TPA-TPP)//graphite Li-DIB：活性物负载 >10 mg cm−2、80 wt.%、面容量1.41 mAh cm−2、稳定600圈。该段没有给测试温度；600圈不能作为上述−20 °C测试的循环数。p型正极PF6−存储及Li-DIB名称可证实DIB方向，但不能据此补全低温全电池构型。

可确认字段：低温−20 °C、100天、100%保持率。低温构型、电解液、窗口、负载、低温循环数、充电倍率、放电倍率及软包性能均NV。原文/SI未取得，故维持待定，不计入主表12篇、不作图。

来源：[出版社存储于Crossref的摘要](https://api.crossref.org/works/10.1002/adfm.202600020)，本地 `sources/adfm.202600020_crossref.json`。Wiley full-xml、advanced/onlinelibrary两处SI PDF URL均HTTP403；Europe PMC无记录。

## 10.1016/j.ensm.2025.104159

题名及DOI真实。现有OpenAlex/Crossref为书目元数据，OpenAlex没有摘要、公开PDF或repository location；Europe PMC无记录。仅有题名“cryogenic conditions”不构成任何数值温度证据。

温度、循环次数、保持率、构型、电解液、窗口、负载、分向倍率和软包性能均NV；DIB详细机制未证实。维持待定，不计入主表12篇、不作图。

已试Elsevier API和ScienceDirect，均为代理Tunnel403；申请升级访问后命令被用户中止，未获得内容。**ESM `1-s2.0-S240582972500159X-mmc1.docx` 未执行尝试**：收到主代理停止追加网络检索的指令，不能把未尝试写成404、403或无SI。

来源：[OpenAlex](https://api.openalex.org/works/https://doi.org/10.1016/j.ensm.2025.104159)，本地 `sources/ensm_openalex.json`。失败访问日志在同一sources目录。

## 作图约束

两篇均没有同次低温循环测试的“循环圈数 + 充电倍率 + 放电倍率”。因此不能产生 X=循环数、Y=放电倍率/充电倍率 的点；尤其不能默认未明确分向的倍率比为1。
