# Proposed R13 · 10.1016/j.cej.2025.166152

High-rate and long-cycle sodium dual-ion batteries via extended π-conjugated polymer for −45-60 °C operation

已检查出版商官方SI的全部文本、表格及关键图像。A–D和−45°C测试温度可由SI核实；全DIB低温循环保持率、圈数及充放电协议未出现在本次取得的SI中，仍须正文。

| 字段 | 可核实值 | 定位 |
|---|---|---|
| A | PPYDPZ || hard carbon (HC)<br>(Na-based DIB full cell; CR2032) | SI General information; Dual-ion full batteries |
| B | 1 M NaBF4 in DEGDME<br>50 µL per SDIB | SI Dual-ion full batteries |
| C | 2.1–4.1 V (SDIB full cell) | SI Dual-ion full batteries; Fig.S12 |
| D | Cathode: source wording “surpassing 2–3” mg cm⁻²<br>HC anode: 1.5–2 mg cm⁻² | SI Na-ion half cells; Dual-ion full batteries |
| E | NV | Available SI examined; main text not acquired in this subtask |
| F | NV | Available SI examined; main text not acquired in this subtask |
| G | NV | Available SI examined; main text not acquired in this subtask |
| H | NV | Available SI examined; main text not acquired in this subtask |
| I | −45 °C (reported chamber tolerance ±2 °C) | SI General information; Fig.S15 |
| J | NV | Available SI examined; main text not acquired in this subtask |
| K | NV | Available SI examined; main text not acquired in this subtask |
| L | NV | Available SI examined; main text not acquired in this subtask |
| M | NV | Available SI examined; main text not acquired in this subtask |

关键限制：Fig.S17的−45°C循环属于HC||Na负极半电池（约17圈），不能用于DIB全电池。Fig.S12的70mA/g（0.5C）为全电池GCD共同标签，但该图无低温标签，仅展示前5圈，因此也不能据此构造低温长期循环图坐标。

当前不能新增严格图或条件图坐标。若主文取得后明确全DIB低温圈数，再与相应试验倍率匹配。

官方SI：https://ars.els-cdn.com/content/image/1-s2.0-S1385894725069906-mmc1.docx

完整原句、图像路径、缺项理由见new_cej_audit.json。