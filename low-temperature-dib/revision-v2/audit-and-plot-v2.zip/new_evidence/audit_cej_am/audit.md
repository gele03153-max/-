# R01与R03逐字段复核

复核范围：现有原始正文、SI及其实际嵌入图片。所有A:M字段均逐项对照。未取得作者原始数据文件，不用图中估读补成精确保持率。

作图结论：两篇均有可核实的低温循环圈数，但原文对相应试验仅提供单一cycling current，没有独立列出的低温充电、放电电流。因此严格数据集中两篇的比值保持空值，不自动填1。

## R01 · 10.1016/j.cej.2024.152602

标题：Electrolyte design for high power dual-ion battery with graphite cathode for low temperature applications

- A:M均已复核；没有把未报告项目填成精确数值。
- 低温测试前在室温活化50圈。100为−20°C试验圈数，不加上室温活化50圈。
- 正文与SI Table S2室温结果确有冲突；保留正文91.5%/2000/5C，不能消除该原始来源冲突。
- −20°C循环只报告at 0.5 C/current density of 0.5 C；未明确独立充、放电设置。
- Fig.S12图内标注−20°C、5.0V–3.0V，没有充放电电流标签；0.5C来自相邻图注和正文。
- NR指已读取正文及SI未报告；没有软包试验，不宜把NR改成No。

| 字段 | 最终值 | 核验定位 |
|---|---|---|
| A | Graphite || Li<br>(dual-ion half-cell; coin) | §4 Electrode preparation and cell fabrication |
| B | 4.8 M LiFSI + 1 wt% LiPF6<br>FEA/DMC = 8:2 (v/v) | §4 Electrolyte preparation |
| C | RT: 3.0–5.1<br>LT: 3.0–5.0 | §4 Electrochemical test |
| D | ≈2.0 (reported electrode loading) | §4 Electrode preparation and cell fabrication |
| E | 91.5% / 2000 / 5C | §2.3; Fig.4c |
| F | 94.8% / 30C<br>(baseline: 2C) | §2.3; Fig.4d |
| G | NR | §4; entirety of available main and SI |
| H | NR | Entirety of available main and SI |
| I | −20 | §2.5; Fig.S12 |
| J | NR / 100 / 0.5C<br>“almost no capacity decay” | Fig.S12 (image12.png); main §2.5 |
| K | NR | §2.5; entirety of main and SI |
| L | NR | Entirety of available main and SI |
| M | NR | Entirety of available main and SI |

逐字段原句、源URL及本地文件路径见 corrections.json。

## R03 · 10.1002/adma.202513832

标题：Comprehensive Understanding of Accelerated Kinetics Driven by Anion–Diluent Dynamics Enabling Wide Temp Operation in Dual‐Ion Batteries

- A:M均已复核；补齐D列25 mg cm⁻²软包载量，H列25 mg cm⁻²、1C、150圈图示记录。
- −20°C循环图仅给5C(500 mA g−1)，没有独立充、放电协议。
- SI DOCX的文本段图号为S26、S27，嵌入图片自身的caption却分别写Supplementary Fig.25和26；引用使用正文及DOCX文本段图号并附图片路径。
- Fig.S27嵌入图片下方caption错误地重复了前一幅温度试验说明；该页上图为10/25mg软包数据，下方复制caption不能作为低温软包证据。DOCX独立文本段正确描述软包测试。
- 图S26a独立caption写20 A g−1，但图中20C(2000mA g−1)、正文20C；这处冲突发生在60°C，不影响−20°C 5C结果。
- Fig.S25的13000圈结果在10000圈更换Li负极、隔膜和电解液；不得当作连续原装电池寿命。
- 低温保留率未精确报告；只凭图估读会改变数据性质，本次不以估读补充为精确值。

| 字段 | 最终值 | 核验定位 |
|---|---|---|
| A | Graphite || Li<br>(coin; separate RT pouch tests) | Supplementary Methods: Electrochemical measurements |
| B | RT: LiTFSI/DMC/HFE = 1:1.64:1.23 (mol)<br>LT: DMC replaced by EMC (LHCE-EMC) | Preparation of electrode and electrolytes; Fig.S26c |
| C | 3.0–5.1 | Supplementary Methods: Electrochemical measurements |
| D | Coin: 2.0–3.0<br>RT pouch: 10 and 25 | Methods; Fig.S27a,c |
| E | 83% / 2000 / 5C | §2.4; Fig.5; Fig.S14 |
| F | NR / 50C<br>87.11 mAh g⁻¹ | §2.4; Fig.5f; Fig.S24 |
| G | Yes (RT) | §2.4 |
| H | 10 mg cm⁻²: NR / 200 / 2C<br>“negligible capacity fading”<br>25 mg cm⁻²: NR / 150 shown / 1C | §2.4; Fig.S27a,c |
| I | −20 | Fig.S26c |
| J | NR / 700 / 5C<br>(LHCE-EMC) | §2.4; Fig.S26c |
| K | NR | Entirety of available main and SI |
| L | NR | Entirety of available main and SI |
| M | NR | Entirety of available main and SI |

逐字段原句、源URL及本地文件路径见 corrections.json。

## 关键图像

- CEJ Fig.S12：`cej2024_si/image12.png`（透明背景）
- AM Fig.S26c：`ADMA-38-e13832-s001/image26.jpeg`
- AM Fig.S27软包：`ADMA-38-e13832-s001/image27.png`

AM原文Data Availability Statement明确：The data that support the findings of this study are available from the corresponding author upon reasonable request. 未发现公开的独立原始电池测试表可用于补齐分开的充放电协议。
