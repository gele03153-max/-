# R10–R12 复核结果

R12取得完整公开正文，已补充电解液及RT/LT循环、RT倍率数据。R10/R11重新核对原始数据库摘要，原表温度、循环数及保持率均与摘要一致，但全文/SI尚不可得，不能补充实验倍率或将放/充倍率比假定为1。

## R12 — 10.1002/adma.73760

公开原文：https://pmc.ncbi.nlm.nih.gov/articles/PMC13431697/ 。正文HTML和各段纯文本已保存至sources。Fig.6和Fig.7已从该公开页面指向的NCBI CDN取得并目视核对。

| 项目 | 核实结果 | 依据 |
|---|---|---|
| 构型 | P(PhTz)正极 || 商业硬碳HC负极；钾双离子全电池 | §2.6、Fig.6a |
| 低温电解液 | 1 M KPF6/DME | §2.7；HTML以small-caps m排版大写M |
| 室温电解液 | 尚未核实 | 配方只在低温章节出现，SI未取得 |
| 电压窗口 | NV | Fig.7c曲线约2.0–4.4V，但未从实验方法得到明确的两端截止电压，不作精确补填 |
| 载量 | LT循环对应载量NV；RT另有80wt%、>3mg cm−2实验 | §2.6/Fig.6g,h；该RT高载量不能转移至LT循环 |
| 室温循环 | 81%/1300/1 A g−1(5C)；78%/150/0.1 A g−1(0.5C) | §2.6、Fig.6d,e |
| 室温倍率 | 作者83%@4 A g−1(20C)，基线0.1 A g−1(0.5C)；135/162mAhg−1 | §2.6、Fig.6f |
| −40°C循环1 | 87%/850/0.1 A g−1(0.5C) | §2.7、Fig.7e |
| −40°C循环2 | 67%/1000/1 A g−1(5C) | §2.7、Fig.7f |
| 低温倍率保持率 | NV | 不将两种不同长循环电流下的容量拼成倍率实验；SI未获 |
| 软包 | NV | 正文明确coin cells，并把soft-package表述为后续放大；未取得SI，保留NV不填no |

正文§2.7同时存在半电池P(PhTz)||K的−40°C数据：99%/290/100mAg−1（Fig.7a,b）。不能把这组半电池结果替换到HC全电池行。

### 纵轴所需的两向倍率证据

Fig.7c明确“GCD curves ... at 100 mA g−1”；Fig.7e为同温度全电池850次、共同标注100mAg−1；Fig.7f共同标注1Ag−1。图与正文均未独立拆出`charge at X; discharge at Y`两向电流，也未取得说明测试协议的SI。因此：

- 严格原始记录：charge_C_rate / discharge_C_rate / ratio均为空。
- 若主任务采用“GCD共同电流意味着名义对称协议”的条件展示：850次和1000次两点Y=1，可用空心标记，`assumption=true`，明确解释名义对称而非两向独立核验。
- 不可使用LT容量保持率87%或67%充当纵轴；纵轴是倍率比。

R12数值不存在主图和正文冲突。1300次的81%位于RT章节；不能写入LT列。850次87%、1000次67%均是真实不同LT全电池实验。

## R10 — 10.1002/adma.202307592

原始EuropePMC core摘要已重新下载保存为`R10_epmc.json`，DOI、作者及题名一致。摘要明确PTPAn正极、HTO负极；−40°C/94.1%/6000次与−60°C/91%/1000次均正确。firstPublicationDate=2023-11-27（dateOfCreation/firstIndexDate不是发表日）。未获得足以核实电解液、截止电压、载量、RT性能、两向LT电流及软包信息的完整来源。

合法来源尝试：Wiley全文、pdfdirect、SI均403；OpenAlex提示PDF/XML available但content下载401需API key；Semantic Scholar记录openAccessPdf为空且标记CLOSED；Harvard DASH检索该题名0条；EuropePMC无PMCID。未绕过授权或挑战。

结论：不改原有摘要可证数值；未知字段继续NV，两条LT结果均不得进入严格倍率比图。尤其不能仅凭6000/1000循环数给Y=1。

## R11 — 10.1002/anie.202406765

EuropePMC core摘要重新下载为`R11_epmc.json`，PTPAn||Ti3C2 MXene、−60°C/86.7%/20000次均正确。firstPublicationDate=2024-08-14。英文Angew anie与德文ange版本不重复计篇。完整Wiley正文/SI403，OpenAlex无fulltext content，EuropePMC无PMCID。未知字段保留NV，不纳入严格倍率比图。

## 另发现的新线索

R12参考文献21是10.1016/j.cej.2025.166152：《High-Rate and Long-Cycle Sodium Dual-Ion Batteries via Extended π-Conjugated Polymer for −45−60°C Operation》，Chemical Engineering Journal 520 (2025)166152。本分任务仅从R12参考文献发现题名/DOI，未独立核验其性能；已发给主任务。
