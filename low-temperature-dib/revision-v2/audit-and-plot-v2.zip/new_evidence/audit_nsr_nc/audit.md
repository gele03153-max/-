# R04/R05 逐字段复核

本复核使用已保存的出版正文、原始SI、Nature Communications Source Data；没有把NR或NV改成猜测值。唯一确定的A:M补全为R05 C：−40°C 0.6–3.0 V。

## 关键结论

- R04：−20°C 12000圈≈100%为原文直接报告，以充分活化后为语境；另有0.2 A g⁻¹的3000圈≈87%。SI p.33 Fig.S25明确“Galvanostatic discharge/charge curves ...1 A g−1”，但未单独给两向电流表。可在条件性图以空心点、Symmetry_assumption=true使用比值1；严格独立协议图不纳入。
- R05：Fig.5b/c/d明确0.6–3.0 V，原NV下限可补0.6。Fig.5c/d共同写GCD at80 mA g⁻¹，方法将CV/LSV与LAND循环区分，未查见其低温循环恒压充电；SI/审稿文件中constant voltage指另一个Zn||MnO₂对照，不能错配。共同GCD条件性比值可置1，仍须明确推定。
- R05 124圈47.8%计算无算术错误：76.0/158.9×100=47.8288%，分母首圈；峰值第23圈195.7，末端/峰值=38.8350%。主图显示至120圈；第120圈97.2，首圈保持率61.1705%。124只是源数据末端，末圈CE79.42%，不是80%循环寿命。条件性图若用124需标注完整源数据末端；若按展示主图用120，不能同时当独立电池点。

## 逐字段证据

### R04 — 10.1093/nsr/nwaf526

**A** PTT-4 || Al；(Swagelok; RT pouch also reported)

证据：SI pp.4–5；Swagelok-type cells were assembled with an organic cathode (diameter: 12 mm), a glass fiber separator (Whatman GF/A, 14 mm), an aluminum foil anode (diameter: 14 mm), and AlCl3/[EMIm]Cl electrolyte (100 μL)

来源：https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12796798/supplementaryFiles

说明：正文称aluminum-organic battery：p型PTT-4可逆结合AlCl4⁻，负极为Al金属/氯铝酸电解液；按Al-DIB储能机制归类，非仅凭标题。

**B** AlCl3/[EMIm]Cl = 1.3:1 (mol)

证据：SI p.5；AlCl3 was slowly added to [EMIm]Cl at a molar ratio of 1.3:1 (AlCl3:[EMIm]Cl)

来源：https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12796798/supplementaryFiles

**C** RT: 0.1–2.2；LT cutoffs: NV

证据：SI p.5; Fig.S25a,b (SI p.33)；Galvanostatic charge/discharge tests were performed on the multichannel battery testing system (Neware BTS-53) in a voltage range of 0.1–2.2 V at 25 ℃.

来源：https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12796798/supplementaryFiles

说明：SI方法仅明确25°C GCD 0.1–2.2 V；低温Fig.S25a,b曲线显示约0.1–2.2 V，但未找到直接声明的低温程序截止值，故保留LT cutoffs NV。室温软包Fig.S17曲线不同下端约0.4 V，不应一概套用。

**D** ≈1.0–1.5 (active material)

证据：SI p.4；The mass loading of active materials is ca. 1.0–1.5 mg cm−2.

来源：https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12796798/supplementaryFiles

**E** NR / 18000 / 10 A g⁻¹；99 mAh g⁻¹ at end

证据：Main Fig.2d; Electrochemical performance section；the PTT-4 cathode demonstrates a high specific capacity of 99 mAh g−1 after 18 000 cycles. The increase in capacity at the beginning of cycling can be attributed to the activation process of porous polymer materials

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC12796798/

说明：活化导致容量变化，未给可直接录入的精确保持率。

**F** 56.4% [calc.] / 10 A g⁻¹；(baseline: 1 A g⁻¹)

证据：Main Fig.2b,c; Electrochemical performance section；capacities of 149, 132, 124, 117, 111, 105, 94 and 84 mAh g−1 at 1, 2, 3, 4, 5, 6, 8 and 10 A g−1, respectively

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC12796798/

说明：室温同一倍率序列，原文容量84和149 mAh g⁻¹。

**G** Yes (RT)

证据：Main Fig.2f,g; SI Fig.S17 p.25；the assembled pouch-type Al||PTT-4 battery delivers a high capacity of 11.0 and 9.7 mAh at 1 and 2 A g−1, respectively

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC12796798/

**H** 93% / 1500 / 1 and 2 A g⁻¹；Rate: 88.2% [calc.] at 2 vs 1 A g⁻¹

证据：Main Fig.2f,g; SI Fig.S17 p.25；exhibits outstanding cycling stability, with a capacity retention of 93% after 1500 cycles (Fig. 2f and g and Fig. S17).

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC12796798/

说明：Fig.S17图中先标1 A g⁻¹，再标2 A g⁻¹；未给精确切换圈数，不自行读数填写。93%为原文报告，9.7/11.0=88.2%为两个电流下全软包容量比。

**I** −20

证据：Main Fig.3g; SI Fig.S25b p.33；Long cycling stability of PTT-4 cathode at 1 A g−1 at −20°C.

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC12796798/

**J** ≈100% / 12000 / 1 A g⁻¹；(after activation)

证据：Main Fig.3g and low-temperature text; SI Fig.S25b p.33；The cycling performance of the PTT-4 cathode at −20°C is also tested after full activation. Impressively, the PTT-4 cathode exhibits extraordinary cycling stability with a capacity retention of ∼100%, even after 12 000 cycles (100 days) at 1 A g−1 (Fig. 3g).

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC12796798/

说明：另有≈87%/3000/0.2 A g⁻¹，见Fig.S25。

**K** 37.9% [calc.] / 5 A g⁻¹；(baseline: 0.05 A g⁻¹)

证据：Main Fig.3e,f; low-temperature text；capacities of 140, 135, 128, 124, 115, 109, 107, 82, 68 and 53 mAh g−1 at 0.05, 0.1, 0.2, 0.3, 0.5, 0.8, 1, 2, 3 and 5 A g−1, respectively

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC12796798/

说明：同为−20°C，不能与RT倍率值直接混为同一倍率分母。

**L** NR

证据：Full main text and SI pp.1–57 inspected；未发现低温软包实验；唯一软包性能为Fig.2f,g / Fig.S17。此处为来源范围内的缺项核查结论，不是原文引句。

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC12796798/

说明：取得的正文与SI仅核实室温软包，未见−20°C软包测试。

**M** NR

证据：Full main text and SI inspected；未发现低温软包循环/倍率数据；此处为来源范围内的缺项核查结论，不是原文引句。

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC12796798/

说明：已检查的正文及SI未给出可直接用于此字段的数值。

### R05 — 10.1038/s41467-026-74628-2

**A** Graphite || PTCDI；(single-layer pouch)

证据：Methods: Electrochemical measurements；pouch cells were assembled in a single-layer configuration by stacking a G positive electrode, a hydrogel electrolyte, and a PTCDI negative electrode.

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC13434426/

说明：原文PTCDI||G按模板换序。

**B** EG-PAM-DG-TFSI-Cl hydrogel；40 vol% EG + 60 vol% aqueous stock；Stock: 1 M LiTFSI + 2 M ZnCl2

证据：Methods: Synthesis of EG-PAM-DG-TFSI-Cl and PAM hydrogel electrolyte；0.01 mol of DG, 0.07 mol of AM, and 0.1 g of IRGACURE 2959 were dissolved in 20 mL of a mixed solution containing 40% EG and 60% (1 M LiTFSI and 2 M ZnCl2) water solution (volume ratio).

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC13434426/

说明：1M与2M描述混入EG前的水溶液，不冒充混合后的最终摩尔浓度。20mL混合液＋0.01mol DG＋0.07mol AM＋0.1g2959，UV聚合。

**C** −40°C: 0.6–3.0 V

证据：Main Fig.5b,c,d, explicit plot annotation；0.6-3.0 V

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC13434426/

说明：已检查原始主图，b/c/d面板明确写0.6–3.0 V；补全原Lower cutoff: NV。不是依据曲线最低点推定。

**D** Graphite: 1.0 (rate); 1.2 (cycling)

证据：SI Table S5 p.13; Main Fig.5 caption；Figure 5b (Rate): Loading mass of G 1 mg cm−2; Loading mass of PTCDI 3.9 mg cm−2. Figure 5d (Cycle): Loading mass of G 1.2 mg cm−2; Loading mass of PTCDI 1.8 mg cm−2.

来源：https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13434426/supplementaryFiles

说明：对应PTCDI载量3.9（倍率）和1.8（循环），不混合两组电池。

**E** NR

证据：Main Results: Activating TFSI− intercalation; Fig.3f; Fig.S13；at 25 °C, PTCDI||G batteries assembled by EG-PAM-DG-Cl and EG-PAM-DG-TFSI-Cl exhibited an obvious ClER when the voltage was swept to 2.2 V

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC13434426/

说明：未给可与−40°C同一DIB反应比较的室温循环保持率。

**F** NR

证据：Full main text / SI inspected；没有取得能直接用于该DIB同一反应的室温倍率保持率。Fig.S13为低温活化后室温放电曲线，不是室温倍率序列。此处为来源核查结论。

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC13434426/

说明：已检查的正文及SI未给出可直接用于此字段的数值。

**G** Yes (cell format)

证据：Methods: Electrochemical measurements；All tests were conducted using pouch cells.

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC13434426/

说明：构型为软包不等于有合格的室温循环结果。

**H** NR

证据：Main / SI inspected；没有取得与−40 °C同一DIB反应对应的室温软包循环保持率与倍率保持率。此处为来源核查结论。

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC13434426/

说明：已检查的正文及SI未给出可直接用于此字段的数值。

**I** −40

证据：Main Fig.5 caption；The electrochemical behaviors of PTCDI||G batteries at -40 °C.

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC13434426/

**J** 47.8% [calc.] / 124 / 80 mA g⁻¹；(reference: cycle 1)

证据：Main Fig.5c,d; Source Data Figure 5!X3:AA126；GCD profiles (c) and the corresponding cycling performance (d) at 80 mA g−1.

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC13434426/

说明：Source Data共124圈：第1圈158.9、第23圈峰值195.7、第120圈97.2、第124圈76.0 mAh g⁻¹。47.8%=76.0/158.9×100为源数据末端/首圈，38.8%为末端/峰值；主图显示至120圈，第120圈/首圈=61.2%。124是数据记录末端，不是80%寿命或正文声明的循环寿命。末圈CE79.42%，须与激活和末端状态一起说明。

**K** 23.4% [calc.] / 100 mA g⁻¹；(baseline: 60 mA g⁻¹)

证据：Main Fig.5a,b / electrochemical performance section；delivering specific capacities of 350, 250, 160, 120, and 82 mAh g−1 at specific currents of 60, 70, 80, 90, and 100 mA g−1, respectively.

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC13434426/

说明：原文列350、250、160、120、82 mAh g⁻¹分别对应60、70、80、90、100 mA g⁻¹。

**L** Yes

证据：Methods; SI Table S5 p.13；All tests were conducted using pouch cells.

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC13434426/

**M** 47.8% [calc.] / 124 / 80 mA g⁻¹；(same pouch test as J)

证据：Main Fig.5c,d; Source Data Figure 5!X3:AA126；GCD profiles (c) and the corresponding cycling performance (d) at 80 mA g−1.

来源：https://pmc.ncbi.nlm.nih.gov/articles/PMC13434426/

说明：Source Data共124圈：第1圈158.9、第23圈峰值195.7、第120圈97.2、第124圈76.0 mAh g⁻¹。47.8%=76.0/158.9×100为源数据末端/首圈，38.8%为末端/峰值；主图显示至120圈，第120圈/首圈=61.2%。124是数据记录末端，不是80%寿命或正文声明的循环寿命。末圈CE79.42%，须与激活和末端状态一起说明。 与J为同一软包实验，不是独立重复。

## 追加可用信息（未自动混入主表）

NC −20°C低载量：SI Fig.S11明确100 mA g⁻¹和0.6–2.5 V；主图到80圈，Source Data第80圈100.6、首圈201.1 mAh g⁻¹，50.0%可计算。Source Data到96圈，末圈放电0，不能把96当稳定寿命。高载量3 mg cm⁻² Fig.S12为33 mA g⁻¹、0.6–2.5 V；源数据末圈30发生明显衰减，主图只显示至约25圈，未推荐新增图点。

图像证据保存在本文件夹：PMC12796798_fig3.jpg、nsr_si_page33.png、PMC13434426_Fig5.jpg、nc_si_page8.png。